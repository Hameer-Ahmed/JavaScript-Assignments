// 1. Declare a variable called username.

// let username;

// 2. Declare a variable called myName & assign to it a string that represents your Full Name.

// let myname = "Hameer Ahmed";

// 3. Write script to

// let message = "Hello World";
// alert(message);

// 4. Write a script to save student’s bio data in JS variables and show the data in alert boxes.

// let StudentName = "Hameer Ahmed";
// let StudentAge = 20;
// let StudentGrade = "A";

// let studentBio =
//   "Name: " + StudentName + "\nAge: " + StudentAge + "\nGrade: " + StudentGrade;
// alert(studentBio);

// 6. Declare a variable called email and assign to it a string that represents your Email Address(e.g. example@example.com). Show the blow mentioned message in an alert box.(Hint: use string concatenation)

// let email = "hameer.langah@gamil.com";
// let message = "My Email Adress is: " + email;
// alert(message);

// 7. Declare a variable called book & give it the value “A smarter way to learn JavaScript”. Display the following message in an alert box:

// let book = "A smarter way to learn JavaScript";
// alert(book);

// 8. Store following string in a variable and show in alert and browser through JS

// alert("“▬▬▬▬▬▬▬▬▬ஜ۩۞۩ஜ▬▬▬▬▬▬▬▬▬”");
